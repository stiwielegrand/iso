s<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Inicio - Isolatec</title>
    <link rel="stylesheet"; href="assets/styles.css?ver=0.4">
    <link href="https://fonts.googleapis.com/css?family=Lora|Open+Sans|Roboto" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Oswald|Source+Sans+Pro" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
</head>
<body>
  <div id="container">
    <header class="">
        <nav class="header">
        <ul>
            <li><a href="index.html">Inicio</a></li>
            <li><a href="servicios.html">Servicios</a></li>
            <li><a href="referencias.html">Referencias</a></li>
            <li><a href="contacto.php">Contacto</a></li>
        </ul>
        </nav>
    </header>
    <section id="float-img"> <img class="coverpic" src="https://www.acvap.org/wp-content/uploads/2018/04/Architecture-Design-House-Modern.jpg" style="max-width: 100%; 
  height: 100%; 
  overflow: hidden; 
  object-fit: cover;
  position:-100px;">
    </section>
    <section id="content">
      <h1>
        Cím tipus 1 verzio
      </h1>
      <h2>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ac elit vel justo lacinia sodales. Maecenas sed feugiat felis. Mauris malesuada sodales nibh sit amet aliquam. Sed tempor commodo imperdiet.
      </h2>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ac elit vel justo lacinia sodales. Maecenas sed feugiat felis. Mauris malesuada sodales nibh sit amet aliquam. Sed tempor commodo imperdiet. Nulla facilisi. Pellentesque nibh arcu, vehicula in purus id, gravida vulputate purus. Nullam bibendum justo arcu, nec commodo nisi dapibus nec. Nulla facilisi. Pellentesque quis tempus ex. Vivamus sed tempor metus. Donec suscipit sem sed ex blandit, ac elementum turpis imperdiet. Ut sit amet nisl a libero semper semper. Integer eu facilisis quam. Aenean iaculis nisi ac ante commodo consequat.

Pellentesque vel turpis vitae massa hendrerit imperdiet. Nulla facilisi. Duis eget molestie dui. Nunc non maximus diam. Phasellus interdum sodales tempus. Morbi semper lorem vitae sapien volutpat varius. Pellentesque lobortis orci id pretium semper.


    </section>
    <footer id="footer">
    </footer>
</div>    
</body>
</html>