THEME: Frontiers - Free Bootstrap 4 Theme
AUTHOR: uiCookies.com
LICENSE: Under Creative Commons 3.0 (uiCookies.com/license)
AUTHOR URI: https://uiCookies.com/


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Demo Images
https://unsplash.com

WayPoints
http://imakewebthings.com/waypoints/

Animate.css
https://daneden.github.io/animate.css/

Slick Slider
https://kenwheeler.github.io/slick/

FontAwesome
https://fontawesome.com/

Ionicons
https://ionicons.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/